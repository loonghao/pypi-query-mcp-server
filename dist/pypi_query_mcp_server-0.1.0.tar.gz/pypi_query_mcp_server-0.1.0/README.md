# PyPI Query MCP Server

A Model Context Protocol (MCP) server for querying PyPI package information, dependencies, and compatibility checking.

## Features

- 📦 Query PyPI package information (name, version, description, dependencies)
- 🐍 Python version compatibility checking
- 🔍 Dependency analysis and resolution
- 🏢 Private PyPI repository support
- ⚡ Fast async operations with caching
- 🛠️ Easy integration with MCP clients

## Quick Start

### Installation

```bash
# Install from PyPI (coming soon)
pip install pypi-query-mcp-server

# Or install from source
git clone https://github.com/loonghao/pypi-query-mcp-server.git
cd pypi-query-mcp-server
poetry install
```

### Usage

```bash
# Start the MCP server
pypi-query-mcp

# Or run directly with Python
python -m pypi_query_mcp.server
```

## Development Status

🚧 **This project is currently in development (MVP phase)**

Current implementation status:
- ✅ Basic project structure
- ⏳ PyPI API client (in progress)
- ⏳ MCP tools implementation (in progress)
- ⏳ Python version compatibility (planned)
- ⏳ Private repository support (planned)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
